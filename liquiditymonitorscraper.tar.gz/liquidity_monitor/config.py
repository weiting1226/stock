"""Registry of the ~13 indicators from 市場流動性雙軌監控系統 (軌道一).

Each entry documents: which category/weight it belongs to in the source
document, where its raw data comes from, and whether this project can
automate it. Three indicators are qualitative-only in the source document
(bid/ask spread change, futures-basis state, ETF fund flow) and have no
free, reliable, long-history public data feed — per the document's own rule
("若有數據無法查證，明確說明「暫缺」，不要臆測填補"), these are marked
``available=False`` and are emitted as all-NaN columns rather than guessed.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class Indicator:
    id: str                # output column name
    name_zh: str
    category: str          # '①'..'⑤' per source document
    category_weight: float  # category weight in 軌道一 composite score
    unit: str
    native_freq: str        # 'D' (daily), 'W' (weekly), 'M' (monthly), 'qual' (qualitative)
    available: bool
    note: str = ""


INDICATORS: list[Indicator] = [
    # ① 總體貨幣流動性 — 25%
    Indicator("fed_balance_sheet_yoy", "Fed資產負債表年增率", "①", 0.25, "%", "W", True,
              "FRED WALCL，週資料換算年增率(52週)"),
    Indicator("on_rrp_balance", "ON RRP餘額", "①", 0.25, "十億美元", "D", True,
              "FRED RRPONTSYD，原始單位為百萬美元，已換算為十億美元"),
    Indicator("m2_yoy", "M2貨幣供給年增率", "①", 0.25, "%", "M", True,
              "FRED M2SL，月資料換算年增率(12個月)"),

    # ② 資金成本與信用 — 25%
    Indicator("hy_oas", "HY信用利差OAS", "②", 0.25, "%", "D", True,
              "FRED BAMLH0A0HYM2"),
    Indicator("t2s10s_bp", "2年10年期公債利差", "②", 0.25, "bp", "D", True,
              "FRED T10Y2Y，原始單位百分點，已換算為bp"),
    Indicator("sofr_ioer_bp", "SOFR-IOER利差", "②", 0.25, "bp", "D", True,
              "FRED SOFR 減 FRED IORB(2021-07起)/IOER(此前)，換算為bp；"
              "SOFR自2018-04才開始發布，之前無法查證"),

    # ③ 市場微觀結構 — 15%（原文件即定義為「可依當下市況質化判斷」）
    Indicator("bid_ask_spread_change", "買賣價差變化", "③", 0.15, "qual", "qual", False,
              "原文件定義為質化判斷項目，無穩定、可回溯十年的免費公開歷史數據源，"
              "暫缺，不臆測填補"),
    Indicator("futures_basis_state", "期貨基差狀態", "③", 0.15, "qual", "qual", False,
              "原文件定義為質化判斷項目，無穩定、可回溯十年的免費公開歷史數據源，"
              "暫缺，不臆測填補"),

    # ④ 風險偏好情緒 — 20%
    Indicator("vix", "VIX", "④", 0.20, "指數", "D", True,
              "Yahoo Finance ^VIX"),
    Indicator("vix_term_diff", "VIX期限結構(VIX9D-VIX)", "④", 0.20, "指數差", "D", True,
              "Yahoo Finance ^VIX9D 減 ^VIX；負值=逆價差，正值=正價差。"
              "^VIX9D 歷史資料約自2011年起才有"),
    Indicator("margin_debt_yoy", "融資餘額年增率", "④", 0.20, "%", "M", True,
              "FINRA margin statistics，月資料換算年增率(12個月)；"
              "此為FINRA網頁表格擷取，未經即時網路驗證，首次執行請人工核對"),

    # ⑤ 跨資產資金流向 — 15%
    Indicator("dxy_1m_change", "DXY美元指數月變動", "⑤", 0.15, "%", "D", True,
              "Yahoo Finance DX-Y.NYB 收盤價之21個交易日(約1個月)變動率；"
              "若Yahoo資料異常則退回FRED DTWEXBGS(貿易加權美元指數)"),
    Indicator("etf_fund_flow", "股票型ETF資金流", "⑤", 0.15, "qual", "qual", False,
              "無可靠、可回溯十年之免費每日歷史資金流數據源(多為付費資料，如ICI/Lipper/ETF.com)，"
              "暫缺，不臆測填補"),
]


RAW_FRED_SERIES = {
    "WALCL": "WALCL",
    "RRPONTSYD": "RRPONTSYD",
    "M2SL": "M2SL",
    "BAMLH0A0HYM2": "BAMLH0A0HYM2",
    "T10Y2Y": "T10Y2Y",
    "SOFR": "SOFR",
    "IORB": "IORB",
    "IOER": "IOER",  # discontinued 2021-07-29, stitched together with IORB
    "DTWEXBGS": "DTWEXBGS",  # fallback for DXY
}

RAW_YAHOO_TICKERS = {
    "VIX": "^VIX",
    "VIX9D": "^VIX9D",
    "DXY": "DX-Y.NYB",
}
