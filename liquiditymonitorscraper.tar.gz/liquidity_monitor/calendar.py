"""US (NYSE) trading-day calendar helpers.

All indicators in this project are US-market liquidity/risk signals, so
"交易日" (trading day) is defined as a NYSE trading session. Purely
rule-based (holidays + weekends) — no network access required.
"""
from __future__ import annotations

import pandas as pd
import pandas_market_calendars as mcal


def nyse_trading_days(start: str, end: str) -> pd.DatetimeIndex:
    """Return all NYSE trading-session dates (tz-naive, normalized) in [start, end]."""
    nyse = mcal.get_calendar("NYSE")
    schedule = nyse.schedule(start_date=start, end_date=end)
    idx = pd.DatetimeIndex(schedule.index).tz_localize(None).normalize()
    return idx
