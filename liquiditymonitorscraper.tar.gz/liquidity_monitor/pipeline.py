"""Fetch, derive, and align all 軌道一 liquidity indicators onto a daily
NYSE trading-day calendar for the trailing N years.

Design:
  1. Fetch each raw series at its native frequency (daily/weekly/monthly).
  2. Compute the derived indicator defined in the source document (YoY %,
     spreads in bp, rolling % change, term-structure diff).
  3. Reindex every derived series onto the full NYSE trading-day calendar and
     forward-fill — e.g. a weekly Fed balance sheet print or a monthly M2
     print is carried forward until the next print, so every trading day has
     a value. Dates before an indicator's first observation are left NaN
     (never back-filled / fabricated).
  4. Merge everything into one wide DataFrame plus a manifest describing
     coverage and data-quality notes per indicator.
"""
from __future__ import annotations

import logging
from typing import Optional

import numpy as np
import pandas as pd

from .calendar import nyse_trading_days
from .config import INDICATORS, RAW_FRED_SERIES, RAW_YAHOO_TICKERS
from .sources.fred import fetch_fred_series
from .sources.yahoo import fetch_yahoo_close
from .sources.finra_margin import fetch_margin_debt

logger = logging.getLogger(__name__)


def _yoy_pct(series: pd.Series, periods: int) -> pd.Series:
    """Percent change vs `periods` observations earlier, at the series' own frequency."""
    return series.pct_change(periods=periods) * 100.0


def _empty() -> pd.Series:
    return pd.Series(dtype=float, index=pd.DatetimeIndex([]))


def _safe_resample_last(series: pd.Series, freq: str) -> pd.Series:
    """Resample to `freq` taking the last value per bucket; no-op on an empty series
    (empty series may carry a RangeIndex, which .resample() rejects)."""
    if series.empty:
        return _empty()
    return series.resample(freq).last()


def _align_to_calendar(series: pd.Series, trading_days: pd.DatetimeIndex) -> pd.Series:
    """Reindex onto the trading-day calendar and forward-fill (no back-fill)."""
    if series.empty:
        return pd.Series(index=trading_days, dtype=float)
    s = series.copy()
    s.index = pd.to_datetime(s.index).normalize()
    s = s[~s.index.duplicated(keep="last")].sort_index()
    combined_index = trading_days.union(s.index)
    aligned = s.reindex(combined_index).ffill()
    return aligned.reindex(trading_days)


def fetch_raw_series(start: str, end: str, fred_api_key: Optional[str] = None,
                      margin_override_csv: Optional[str] = None) -> dict[str, pd.Series]:
    """Fetch every raw series this project knows how to pull. Failures are
    caught per-series so one bad source doesn't take down the whole run."""
    raw: dict[str, pd.Series] = {}

    for local_id, fred_id in RAW_FRED_SERIES.items():
        try:
            raw[local_id] = fetch_fred_series(fred_id, start, end, api_key=fred_api_key)
            logger.info("FRED %s: %d obs", fred_id, len(raw[local_id]))
        except Exception as exc:  # noqa: BLE001
            logger.warning("FRED %s 抓取失敗: %s", fred_id, exc)
            raw[local_id] = _empty()

    for local_id, ticker in RAW_YAHOO_TICKERS.items():
        try:
            raw[local_id] = fetch_yahoo_close(ticker, start, end)
            logger.info("Yahoo %s: %d obs", ticker, len(raw[local_id]))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Yahoo %s 抓取失敗: %s", ticker, exc)
            raw[local_id] = _empty()

    try:
        raw["MARGIN_DEBT"] = fetch_margin_debt(start, end, override_csv=margin_override_csv)
        logger.info("FINRA margin debt: %d obs", len(raw["MARGIN_DEBT"]))
    except Exception as exc:  # noqa: BLE001
        logger.warning("FINRA 融資餘額抓取失敗: %s", exc)
        raw["MARGIN_DEBT"] = _empty()

    return raw


def _sofr_ioer_spread_raw(raw: dict[str, pd.Series]) -> pd.Series:
    """IORB (2021-07-29 onward) stitched onto its predecessor IOER for history before that."""
    ioer, iorb = raw.get("IOER", _empty()), raw.get("IORB", _empty())
    if ioer.empty and iorb.empty:
        return _empty()
    floor_rate = pd.concat([ioer[~ioer.index.isin(iorb.index)], iorb]).sort_index()
    sofr = raw.get("SOFR", _empty())
    if sofr.empty or floor_rate.empty:
        return _empty()
    df = pd.concat({"sofr": sofr, "floor": floor_rate}, axis=1).dropna()
    return (df["sofr"] - df["floor"]) * 100.0  # percentage points -> bp


def derive_indicators(raw: dict[str, pd.Series]) -> dict[str, pd.Series]:
    """Compute every derived indicator defined in config.INDICATORS from raw series."""
    derived: dict[str, pd.Series] = {}

    walcl_weekly = _safe_resample_last(raw.get("WALCL", _empty()), "W-WED")
    derived["fed_balance_sheet_yoy"] = _yoy_pct(walcl_weekly, 52)

    # FRED RRPONTSYD is already reported in billions of USD (matches the
    # source document's threshold unit of 十億美元), no conversion needed.
    derived["on_rrp_balance"] = raw.get("RRPONTSYD", _empty())

    m2_monthly = _safe_resample_last(raw.get("M2SL", _empty()), "MS")
    derived["m2_yoy"] = _yoy_pct(m2_monthly, 12)

    derived["hy_oas"] = raw.get("BAMLH0A0HYM2", _empty())

    t2s10s = raw.get("T10Y2Y", _empty())
    derived["t2s10s_bp"] = t2s10s * 100.0

    derived["sofr_ioer_bp"] = _sofr_ioer_spread_raw(raw)

    derived["vix"] = raw.get("VIX", _empty())

    vix, vix9d = raw.get("VIX", _empty()), raw.get("VIX9D", _empty())
    if not vix.empty and not vix9d.empty:
        df = pd.concat({"vix": vix, "vix9d": vix9d}, axis=1).dropna()
        derived["vix_term_diff"] = df["vix9d"] - df["vix"]
    else:
        derived["vix_term_diff"] = _empty()

    margin_monthly = _safe_resample_last(raw.get("MARGIN_DEBT", _empty()), "MS")
    derived["margin_debt_yoy"] = _yoy_pct(margin_monthly, 12)

    dxy = raw.get("DXY", _empty())
    if dxy.empty:
        # FRED DTWEXBGS fallback (broad trade-weighted dollar index; different
        # composition than ICE DXY, kept only as an availability fallback)
        dxy = raw.get("DTWEXBGS", _empty())
    derived["dxy_1m_change"] = dxy.pct_change(periods=21) * 100.0

    # Qualitative / unavailable indicators: emit NaN placeholders, never fabricated.
    derived["bid_ask_spread_change"] = _empty()
    derived["futures_basis_state"] = _empty()
    derived["etf_fund_flow"] = _empty()

    return derived


def build_daily_dataset(
    start: str,
    end: str,
    fred_api_key: Optional[str] = None,
    margin_override_csv: Optional[str] = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return (daily_df, manifest_df) for the trailing period [start, end]."""
    trading_days = nyse_trading_days(start, end)

    raw = fetch_raw_series(start, end, fred_api_key=fred_api_key,
                            margin_override_csv=margin_override_csv)
    derived = derive_indicators(raw)

    columns = {}
    manifest_rows = []
    for ind in INDICATORS:
        series = derived.get(ind.id, _empty())
        aligned = _align_to_calendar(series, trading_days) if ind.available else pd.Series(
            np.nan, index=trading_days
        )
        columns[ind.id] = aligned

        n_valid = int(aligned.notna().sum())
        manifest_rows.append({
            "id": ind.id,
            "name_zh": ind.name_zh,
            "category": ind.category,
            "category_weight": ind.category_weight,
            "unit": ind.unit,
            "native_freq": ind.native_freq,
            "available": ind.available,
            "first_valid_date": aligned.first_valid_index(),
            "last_valid_date": aligned.last_valid_index(),
            "n_valid_days": n_valid,
            "coverage_pct": round(100.0 * n_valid / len(trading_days), 1) if len(trading_days) else 0.0,
            "note": ind.note,
        })

    daily_df = pd.DataFrame(columns, index=trading_days)
    daily_df.index.name = "trading_date"

    manifest_df = pd.DataFrame(manifest_rows)
    return daily_df, manifest_df
