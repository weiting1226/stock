"""FINRA margin statistics (股票融資餘額 / margin debt) scraper.

FINRA publishes month-end margin debit-balance statistics at:
    https://www.finra.org/investors/learn-to-invest/advanced-investing/margin-statistics

This page has historically been rendered as a plain HTML table, but FINRA has
changed its layout more than once. This scraper was written and unit-tested
against a mocked HTML fixture (see tests/test_pipeline.py) because the sandbox
this code was authored in has no outbound network access to finra.org — treat
the live parsing path as untested against the real site and verify the output
the first time you run it with internet access. If FINRA's markup has changed,
`fetch_margin_debt` raises a clear error rather than silently returning wrong
numbers; pass `override_csv` to bypass scraping entirely with a manually
downloaded file (columns: date, margin_debt).
"""
from __future__ import annotations

from typing import Optional

import pandas as pd
import requests

FINRA_URL = "https://www.finra.org/investors/learn-to-invest/advanced-investing/margin-statistics"

_HEADERS = {"User-Agent": "Mozilla/5.0 (liquidity-monitor scraper)"}


def _find_margin_table(tables: list[pd.DataFrame]) -> pd.DataFrame:
    for t in tables:
        cols = [str(c).strip().lower() for c in t.columns]
        has_debit = any("debit" in c for c in cols)
        has_period = any(("month" in c) or ("year" in c) or ("date" in c) for c in cols)
        if has_debit and has_period:
            return t
    raise ValueError(
        "無法從 FINRA 頁面找到含 'Debit' 與 'Month/Year' 欄位的表格；"
        "網站結構可能已變更，請人工檢查頁面並更新 finra_margin._find_margin_table，"
        "或改用 override_csv 參數提供手動下載的資料。"
    )


def fetch_margin_debt(
    start: str,
    end: str,
    timeout: int = 30,
    override_csv: Optional[str] = None,
) -> pd.Series:
    """Return a monthly margin-debit-balance series indexed by month-end date, in USD.

    FINRA reports "Debit Balances in Customers' Securities Margin Accounts" in
    millions of dollars; we convert to USD for consistency with other dollar
    series (e.g. WALCL is reported in millions by FRED too — see pipeline.py
    for unit normalization).
    """
    if override_csv:
        df = pd.read_csv(override_csv)
        df.columns = [c.strip().lower() for c in df.columns]
        s = df.set_index(pd.to_datetime(df["date"]))["margin_debt"].sort_index()
        return s.loc[start:end].astype(float).rename("MARGIN_DEBT")

    resp = requests.get(FINRA_URL, headers=_HEADERS, timeout=timeout)
    resp.raise_for_status()
    tables = pd.read_html(resp.text)
    table = _find_margin_table(tables)

    period_col = next(c for c in table.columns if any(k in str(c).lower() for k in ("month", "year", "date")))
    debit_col = next(c for c in table.columns if "debit" in str(c).lower())

    out = table[[period_col, debit_col]].copy()
    out.columns = ["date", "value"]
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    out["value"] = (
        out["value"].astype(str).str.replace(",", "", regex=False).str.replace("$", "", regex=False)
    )
    out["value"] = pd.to_numeric(out["value"], errors="coerce") * 1_000_000  # millions -> USD
    out = out.dropna().set_index("date").sort_index()["value"]

    return out.loc[start:end].rename("MARGIN_DEBT")
