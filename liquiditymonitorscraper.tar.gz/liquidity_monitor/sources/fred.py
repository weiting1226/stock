"""FRED (Federal Reserve Economic Data) fetchers.

Two access paths are supported:
  1. Official API (`api.stlouisfed.org/fred/series/observations`) — used when
     a FRED API key is available (env var FRED_API_KEY or passed explicitly).
     Free to obtain at https://fredaccount.stlouisfed.org/apikeys.
  2. Public CSV endpoint (`fred.stlouisfed.org/graph/fredgraph.csv`) — no key
     required, used as the default / fallback since it is what FRED's own
     "download data" button on every series page produces.
"""
from __future__ import annotations

import io
import os
from typing import Optional

import pandas as pd
import requests

FRED_CSV_URL = "https://fred.stlouisfed.org/graph/fredgraph.csv"
FRED_API_URL = "https://api.stlouisfed.org/fred/series/observations"

_SESSION = requests.Session()
_SESSION.headers.update({"User-Agent": "Mozilla/5.0 (liquidity-monitor scraper)"})


def _to_series(df: pd.DataFrame, date_col: str, value_col: str) -> pd.Series:
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
    s = df.set_index(date_col)[value_col].sort_index()
    s.name = value_col
    return s.dropna()


def fetch_fred_csv(series_id: str, start: str, end: str, timeout: int = 30) -> pd.Series:
    """Fetch a FRED series via the public CSV endpoint (no API key needed)."""
    params = {"id": series_id, "cosd": start, "coed": end}
    resp = _SESSION.get(FRED_CSV_URL, params=params, timeout=timeout)
    resp.raise_for_status()
    text = resp.text
    if text.strip().startswith("<") or "series does not exist" in text.lower():
        raise ValueError(f"FRED series '{series_id}' 無法解析 (可能代碼錯誤或已下架)")
    df = pd.read_csv(io.StringIO(text))
    df.columns = ["date", "value"]
    return _to_series(df, "date", "value").rename(series_id)


def fetch_fred_api(
    series_id: str, start: str, end: str, api_key: Optional[str] = None, timeout: int = 30
) -> pd.Series:
    """Fetch a FRED series via the official JSON API. Requires an API key."""
    api_key = api_key or os.environ.get("FRED_API_KEY")
    if not api_key:
        raise ValueError("需要 FRED_API_KEY 才能使用官方 API，請改用 fetch_fred_csv 或設定金鑰")
    params = {
        "series_id": series_id,
        "api_key": api_key,
        "file_type": "json",
        "observation_start": start,
        "observation_end": end,
    }
    resp = _SESSION.get(FRED_API_URL, params=params, timeout=timeout)
    resp.raise_for_status()
    obs = resp.json().get("observations", [])
    df = pd.DataFrame(obs)
    if df.empty:
        return pd.Series(dtype=float, name=series_id)
    df["value"] = df["value"].replace(".", pd.NA)
    return _to_series(df[["date", "value"]], "date", "value").rename(series_id)


def fetch_fred_series(
    series_id: str, start: str, end: str, api_key: Optional[str] = None, timeout: int = 30
) -> pd.Series:
    """Fetch a FRED series, preferring the official API when a key is available,
    falling back to the public CSV endpoint otherwise."""
    api_key = api_key or os.environ.get("FRED_API_KEY")
    if api_key:
        try:
            return fetch_fred_api(series_id, start, end, api_key=api_key, timeout=timeout)
        except Exception:
            pass
    return fetch_fred_csv(series_id, start, end, timeout=timeout)
