"""Yahoo Finance fetchers (VIX, VIX9D, DXY) via yfinance."""
from __future__ import annotations

import pandas as pd
import yfinance as yf


def fetch_yahoo_close(ticker: str, start: str, end: str) -> pd.Series:
    """Fetch daily close prices for a Yahoo Finance ticker (e.g. '^VIX', 'DX-Y.NYB')."""
    df = yf.download(
        ticker,
        start=start,
        end=end,
        progress=False,
        auto_adjust=False,
        threads=False,
    )
    if df is None or df.empty:
        return pd.Series(dtype=float, name=ticker)

    close = df["Close"]
    if isinstance(close, pd.DataFrame):
        # yfinance sometimes returns a MultiIndex column frame even for one ticker
        close = close.iloc[:, 0]

    close = close.copy()
    close.index = pd.to_datetime(close.index).tz_localize(None)
    close.name = ticker
    return close.sort_index().dropna()
