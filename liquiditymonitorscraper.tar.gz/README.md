# 市場流動性雙軌監控系統 — 軌道一指標自動爬蟲

依據《市場流動性雙軌監控系統》提示詞文件中「軌道一：中期趨勢燈號」定義的
13 項指標，自動抓取近十年歷史資料，並對齊到每個 NYSE 交易日（缺值以前值
前向填補，補齊週/月頻資料到每日頻率），輸出成一份寬表 CSV，供後續分析
（如計算文件中定義的燈號評分）使用。

> 「軌道二：即時應變層」屬於盤中/當日事件確認機制，本質上不是可回溯十年的
> 歷史時間序列（多數項目需要即時盤中報價、熔斷紀錄等），不在本次「爬歷史
> 資料」的範疇內，故本專案未實作。

## ⚠️ 重要限制：本次開發環境沒有對外網路權限

這份程式碼是在一個網路出口受管控的沙盒中撰寫與測試的。實測結果：

```
fred.stlouisfed.org          -> 403 (policy denial)
query1.finance.yahoo.com     -> 403 (policy denial)
www.finra.org                -> 403 (policy denial)
api.stlouisfed.org           -> 403 (policy denial)
```

也就是說 **本次任務無法在此環境中實際執行爬蟲、下載十年歷史資料**。所有
抓取/轉換/對齊邏輯都已用 mock 資料驗證正確（見 `tests/`），但尚未對真實
網站的回應格式做過即時驗證 — 特別是 FINRA 網頁表格的欄位命名（見下方
「已知風險」）。

**請在有對外網路存取權限的環境（本機電腦、或允許存取
fred.stlouisfed.org / finance.yahoo.com / finra.org 的另一個環境）執行
`scripts/run_scraper.py`**，取得實際資料。

## 指標對應總表

| 類別 | 指標 | 欄位 id | 資料來源 | 原生頻率 | 狀態 |
|---|---|---|---|---|---|
| ①總體貨幣流動性 | Fed資產負債表年增率 | `fed_balance_sheet_yoy` | FRED `WALCL` | 週 | ✅ 自動 |
| ① | ON RRP餘額 | `on_rrp_balance` | FRED `RRPONTSYD` | 日 | ✅ 自動 |
| ① | M2貨幣供給年增率 | `m2_yoy` | FRED `M2SL` | 月 | ✅ 自動 |
| ②資金成本與信用 | HY信用利差OAS | `hy_oas` | FRED `BAMLH0A0HYM2` | 日 | ✅ 自動 |
| ② | 2年10年期公債利差 | `t2s10s_bp` | FRED `T10Y2Y`（換算為bp） | 日 | ✅ 自動 |
| ② | SOFR-IOER利差 | `sofr_ioer_bp` | FRED `SOFR` − (`IORB`/`IOER`) | 日 | ✅ 自動（SOFR僅自2018-04起有資料）|
| ③市場微觀結構 | 買賣價差變化 | `bid_ask_spread_change` | — | — | ❌ 暫缺（原文件定義為質化判斷，無公開歷史數據源）|
| ③ | 期貨基差狀態 | `futures_basis_state` | — | — | ❌ 暫缺（同上）|
| ④風險偏好情緒 | VIX | `vix` | Yahoo `^VIX` | 日 | ✅ 自動 |
| ④ | VIX期限結構 | `vix_term_diff` | Yahoo `^VIX9D` − `^VIX` | 日 | ✅ 自動（^VIX9D約2011年後才有資料）|
| ④ | 融資餘額年增率 | `margin_debt_yoy` | FINRA margin statistics | 月 | ✅ 自動，但**網頁解析未經即時驗證**，見下 |
| ⑤跨資產資金流向 | DXY美元指數月變動 | `dxy_1m_change` | Yahoo `DX-Y.NYB`（失敗時退回 FRED `DTWEXBGS`） | 日 | ✅ 自動 |
| ⑤ | 股票型ETF資金流 | `etf_fund_flow` | — | — | ❌ 暫缺（無免費、可回溯十年的每日資金流數據源）|

3 項標記「❌ 暫缺」的欄位在輸出中永遠是全 `NaN`，並在 `manifest.csv` 中
`available=False`、`coverage_pct=0` — 依照原文件第103行的原則「若有數據
無法查證，明確說明『暫缺』，不要臆測填補」，本專案對抓不到的指標採取
同樣做法，絕不用其他數字頂替。

## 安裝

```bash
pip install -r requirements.txt
```

## 使用方式

```bash
# 抓取「今天」往回推 10 年（預設）
python3 scripts/run_scraper.py --out data/

# 指定區間
python3 scripts/run_scraper.py --start 2016-01-01 --end 2026-01-01 --out data/

# 有 FRED API 金鑰時可用（https://fredaccount.stlouisfed.org/apikeys 免費申請）
python3 scripts/run_scraper.py --fred-api-key YOUR_KEY --out data/

# 若 FINRA 網頁解析失敗，可改用手動下載的 CSV（欄位: date, margin_debt）
python3 scripts/run_scraper.py --margin-override-csv path/to/margin.csv --out data/
```

輸出到 `--out` 指定的資料夾：

- `liquidity_indicators_daily.csv`：以 NYSE 交易日為索引的寬表，每欄一個指標，
  已前向填補到每個交易日。
- `manifest.csv`：每個指標的資料可用性報告（首/末筆有效日期、涵蓋率、單位、
  類別權重、備註）— **拿到資料後請先看這份檔案**，確認涵蓋率與日期範圍
  符合預期，尤其是 FINRA 融資餘額那一列。

## 已知風險 / 下次執行時請人工核對

1. **FINRA 融資餘額網頁解析**（`liquidity_monitor/sources/finra_margin.py`）：
   因本沙盒連不到 `finra.org`，`_find_margin_table` 的欄位比對規則
   （尋找同時含 "debit" 與 "month/year/date" 字樣的欄位）是依據 FINRA
   過往頁面結構撰寫，**未對即時頁面驗證**。若解析失敗會拋出清楚的錯誤訊息
   而不是回傳錯誤數字；此時請用 `--margin-override-csv` 手動提供資料。
2. **DXY**：Yahoo `DX-Y.NYB` 是最貼近原文件「DXY美元指數」定義的公開來源；
   若抓取失敗會自動退回 FRED `DTWEXBGS`（貿易加權美元指數），但兩者編制
   方式不同，`manifest.csv` 不會特別標記實際使用了哪個來源，如需嚴謹分析
   請自行確認 `dxy_1m_change` 的資料是否對得上 ICE DXY 走勢。
3. **SOFR-IOER利差**：SOFR 於 2018-04-03 才開始發布，之前的日期此欄位必為
   `NaN`（非抓取失敗，是資料本來就不存在）。

## 執行測試

```bash
pip install pytest
python3 -m pytest tests/ -v
```

所有測試使用 mock/合成資料，不需要網路連線，驗證的是抓取解析、年增率
計算、交易日對齊/前向填補、以及「暫缺欄位不臆測填補」等核心邏輯。
