"""Unit tests using mocked/synthetic data — no network access required or used.

These verify the parsing and alignment *logic* (FRED CSV parsing, trading-day
reindex/ffill, YoY math, unavailable-indicator handling). They do not verify
that finra.org's or Yahoo's live HTML/JSON still matches the shapes assumed
here, since this sandbox cannot reach those hosts (see README's network
caveat) — re-run scripts/run_scraper.py with real internet access at least
once and sanity-check the manifest before trusting the output.
"""
from __future__ import annotations

from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest

from liquidity_monitor.calendar import nyse_trading_days
from liquidity_monitor.pipeline import (
    _align_to_calendar,
    _yoy_pct,
    build_daily_dataset,
    derive_indicators,
)
from liquidity_monitor.sources.fred import fetch_fred_csv
from liquidity_monitor.sources.finra_margin import _find_margin_table


class _FakeResponse:
    def __init__(self, text: str, status_code: int = 200):
        self.text = text
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


def test_fred_csv_parses_missing_values_as_nan_and_drops_them():
    csv_text = "DATE,DGS10\n2024-01-01,.\n2024-01-02,4.05\n2024-01-03,4.10\n"
    with patch("liquidity_monitor.sources.fred._SESSION.get", return_value=_FakeResponse(csv_text)):
        s = fetch_fred_csv("DGS10", "2024-01-01", "2024-01-03")
    assert list(s.index.strftime("%Y-%m-%d")) == ["2024-01-02", "2024-01-03"]
    assert s.iloc[0] == pytest.approx(4.05)


def test_nyse_calendar_excludes_weekends_and_known_holiday():
    days = nyse_trading_days("2024-01-01", "2024-01-05")
    day_strs = set(days.strftime("%Y-%m-%d"))
    assert "2024-01-01" not in day_strs  # New Year's Day holiday
    assert "2024-01-06" not in day_strs  # Saturday (out of range anyway)
    assert "2024-01-02" in day_strs
    assert "2024-01-03" in day_strs


def test_yoy_pct_basic():
    s = pd.Series([100.0, 110.0, 121.0], index=pd.date_range("2023-01-01", periods=3, freq="MS"))
    out = _yoy_pct(s, 1)
    assert out.iloc[1] == pytest.approx(10.0)
    assert out.iloc[2] == pytest.approx(10.0)
    assert np.isnan(out.iloc[0])


def test_align_to_calendar_forward_fills_and_does_not_backfill():
    trading_days = pd.DatetimeIndex(["2024-01-02", "2024-01-03", "2024-01-04", "2024-01-05"])
    weekly = pd.Series([1.0, 2.0], index=pd.to_datetime(["2024-01-03", "2024-01-10"]))
    aligned = _align_to_calendar(weekly, trading_days)
    assert np.isnan(aligned.loc["2024-01-02"])  # before first observation: no backfill
    assert aligned.loc["2024-01-03"] == 1.0
    assert aligned.loc["2024-01-04"] == 1.0  # forward-filled
    assert aligned.loc["2024-01-05"] == 1.0


def test_derive_indicators_unavailable_columns_are_all_nan():
    derived = derive_indicators({})
    for qual_id in ("bid_ask_spread_change", "futures_basis_state", "etf_fund_flow"):
        assert derived[qual_id].empty


def test_finra_table_matcher_picks_debit_month_table():
    good = pd.DataFrame({"Month/Year": ["Jan-24"], "Debit Balances ($MM)": ["800,000"]})
    other = pd.DataFrame({"Foo": [1], "Bar": [2]})
    picked = _find_margin_table([other, good])
    assert "Debit Balances ($MM)" in picked.columns


def test_finra_table_matcher_raises_when_no_match():
    with pytest.raises(ValueError):
        _find_margin_table([pd.DataFrame({"Foo": [1]})])


def test_build_daily_dataset_marks_unavailable_indicators_as_nan_with_zero_coverage():
    fake_raw = {
        "WALCL": pd.Series(dtype=float),
        "RRPONTSYD": pd.Series(dtype=float),
        "M2SL": pd.Series(dtype=float),
        "BAMLH0A0HYM2": pd.Series(dtype=float),
        "T10Y2Y": pd.Series(dtype=float),
        "SOFR": pd.Series(dtype=float),
        "IORB": pd.Series(dtype=float),
        "IOER": pd.Series(dtype=float),
        "DTWEXBGS": pd.Series(dtype=float),
        "VIX": pd.Series(dtype=float),
        "VIX9D": pd.Series(dtype=float),
        "DXY": pd.Series(dtype=float),
        "MARGIN_DEBT": pd.Series(dtype=float),
    }
    with patch("liquidity_monitor.pipeline.fetch_raw_series", return_value=fake_raw):
        daily_df, manifest_df = build_daily_dataset("2024-01-01", "2024-01-10")

    unavailable_row = manifest_df.set_index("id").loc["etf_fund_flow"]
    assert unavailable_row["available"] == False  # noqa: E712
    assert unavailable_row["coverage_pct"] == 0.0
    assert daily_df["etf_fund_flow"].isna().all()
