#!/usr/bin/env python3
"""CLI entrypoint: scrape the 軌道一 liquidity indicators for the trailing
N years and write a daily, trading-day-aligned CSV.

Example:
    python3 scripts/run_scraper.py --years 10 --out data/

Requires outbound internet access to fred.stlouisfed.org, query*.finance.yahoo.com,
and www.finra.org — this will fail in network-sandboxed environments.
"""
from __future__ import annotations

import argparse
import logging
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from liquidity_monitor.pipeline import build_daily_dataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--years", type=int, default=10, help="回溯年數 (預設 10)")
    parser.add_argument("--start", type=str, default=None, help="起始日 YYYY-MM-DD (覆蓋 --years)")
    parser.add_argument("--end", type=str, default=None, help="結束日 YYYY-MM-DD (預設今天)")
    parser.add_argument("--out", type=str, default="data", help="輸出資料夾")
    parser.add_argument("--fred-api-key", type=str, default=None,
                         help="FRED API 金鑰 (可選；未提供則使用免金鑰 CSV 端點)")
    parser.add_argument("--margin-override-csv", type=str, default=None,
                         help="以本機 CSV (欄位: date, margin_debt) 取代 FINRA 網頁擷取")
    parser.add_argument("-v", "--verbose", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(asctime)s %(levelname)s %(message)s",
    )

    end = args.end or date.today().isoformat()
    if args.start:
        start = args.start
    else:
        end_date = date.fromisoformat(end)
        start = end_date.replace(year=end_date.year - args.years).isoformat()

    print(f"抓取區間: {start} ~ {end}")
    daily_df, manifest_df = build_daily_dataset(
        start, end, fred_api_key=args.fred_api_key, margin_override_csv=args.margin_override_csv
    )

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    daily_path = out_dir / "liquidity_indicators_daily.csv"
    manifest_path = out_dir / "manifest.csv"

    daily_df.to_csv(daily_path)
    manifest_df.to_csv(manifest_path, index=False)

    print(f"已寫入每日資料: {daily_path} ({len(daily_df)} 個交易日 x {len(daily_df.columns)} 項指標)")
    print(f"已寫入資料清單/涵蓋率: {manifest_path}")
    print()
    print(manifest_df[["id", "name_zh", "available", "coverage_pct", "first_valid_date", "last_valid_date"]]
          .to_string(index=False))


if __name__ == "__main__":
    main()
